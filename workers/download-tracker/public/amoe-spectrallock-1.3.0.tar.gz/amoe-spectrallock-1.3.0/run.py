#!/usr/bin/env python3
"""AMOE-1.3 entry. Author: Aziel Eliab."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from amoe.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
